package com.github.flykhalil.twitter.core.model;

import com.github.flykhalil.twitter.core.exception.DataAccessException;

/**
 * Created by IntelliJ IDEA.
 * User: rsv
 * Date: 09.11.2020
 * Time: 1:52
 */
public interface IAdminPanel {

    int getTotalNumberOfUsers() throws DataAccessException;

    int getTotalNumberOfGroups() throws DataAccessException;

    int getTotalNumberOfTweets() throws DataAccessException;

    double getPositivePercentageOfTweets() throws DataAccessException;
}
