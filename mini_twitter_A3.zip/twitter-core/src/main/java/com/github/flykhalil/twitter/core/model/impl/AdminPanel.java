package com.github.flykhalil.twitter.core.model.impl;

import com.github.flykhalil.twitter.core.exception.DataAccessException;
import com.github.flykhalil.twitter.core.model.IAdminPanel;
import com.github.flykhalil.twitter.core.model.ITweet;
import com.github.flykhalil.twitter.core.storage.RepositoryHolder;

import java.util.Arrays;
import java.util.Map;
import java.util.UUID;

/**
 * Created by IntelliJ IDEA.
 * User: rsv
 * Date: 10.11.2020
 * Time: 0:34
 */
public class AdminPanel implements IAdminPanel {

    private static final String[] POSITIVE_WORDS =
            new String[] {"good", "great", "excellent", "perfect", "funny", "best", "love"};

    @Override
    public int getTotalNumberOfUsers() throws DataAccessException {
        return RepositoryHolder.getUserRepository().findAll().size();
    }

    @Override
    public int getTotalNumberOfGroups() throws DataAccessException {
        return RepositoryHolder.getGroupRepository().findAll().size();
    }

    @Override
    public int getTotalNumberOfTweets() throws DataAccessException {
        return RepositoryHolder.getTweetRepository().findAll().size();
    }

    @Override
    public double getPositivePercentageOfTweets() throws DataAccessException {
        //@formatter:off
        Map<UUID, ITweet> tweetMap =RepositoryHolder.getTweetRepository().findAll();
        int allTweetsNumber = tweetMap.size();
        long positiveTweets = tweetMap
                                .values()
                                .stream()
                                .filter(tweet -> Arrays.stream(POSITIVE_WORDS)
                                                       .anyMatch(positiveWord -> tweet
                                                               .getTweetText()
                                                               .toLowerCase()
                                                               .contains(positiveWord)))
                                .count();
        //@formatter:on
        if (allTweetsNumber < 1) {
            return 0.0;
        }
        else {
            return (double) positiveTweets / allTweetsNumber;
        }
    }
}
