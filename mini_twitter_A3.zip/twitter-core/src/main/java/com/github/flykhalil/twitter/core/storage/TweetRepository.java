package com.github.flykhalil.twitter.core.storage;

import com.github.flykhalil.twitter.core.exception.DataAccessException;
import com.github.flykhalil.twitter.core.model.ITweet;
import com.github.flykhalil.twitter.core.model.IUser;

import java.io.IOException;
import java.util.HashSet;
import java.util.Set;
import java.util.UUID;
import java.util.stream.Collectors;

/**
 * Created by IntelliJ IDEA.
 * User: rsv
 * Date: 09.11.2020
 * Time: 22:20
 */
public class TweetRepository extends AbstractFileRepository<ITweet, UUID> {

    public TweetRepository() throws IOException, DataAccessException {
        super();
    }

    @Override
    public void save(final UUID id, final ITweet tweet) throws DataAccessException {
        super.save(id, tweet);
        long ownerId = tweet.getOwnerId();
        Set<Long> toUpdateUserIds = new HashSet<>(RepositoryHolder.getUserRepository().findById(ownerId).getFollowersUserIds());
        toUpdateUserIds.add(ownerId);
        for (Long toUpdateUserId : toUpdateUserIds) {
            IUser user = RepositoryHolder.getUserRepository().findById(toUpdateUserId);
            user.inheritLasUpdateTimeFormTweet(tweet);
            RepositoryHolder.getUserRepository().save(toUpdateUserId, user);
        }
    }

    public Set<ITweet> findTweetsByOwnerIdIn(final Set<Long> userIds) throws DataAccessException {
        return findAll().values().stream().filter(tweet -> userIds.contains(tweet.getOwnerId())).collect(Collectors.toSet());
    }

    public Set<ITweet> findTweetsByOwnerId(final Long userId) throws DataAccessException {
        return findAll().values().stream().filter(tweet -> userId == tweet.getOwnerId()).collect(Collectors.toSet());
    }
}
