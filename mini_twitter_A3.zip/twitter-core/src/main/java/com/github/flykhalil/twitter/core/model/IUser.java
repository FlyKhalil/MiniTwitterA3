package com.github.flykhalil.twitter.core.model;

import java.io.Serializable;
import java.util.Set;

/**
 * Created by IntelliJ IDEA.
 * User: rsv
 * Date: 09.11.2020
 * Time: 0:49
 */
public interface IUser extends Serializable {

    void addFollowerUserId(long followerUserId);

    void addFollowingUserId(long followingUserId);

    String getName();

    long getId();

    long getCreationTime();

    void inheritLasUpdateTimeFormTweet(ITweet tweet);

    long getLastUpdateTime();

    Set<Long> getFollowersUserIds();

    Set<Long> getFollowingUserIds();
}
