package com.github.flykhalil.twitter.core.model.impl;

import com.github.flykhalil.twitter.core.exception.DataAccessException;
import com.github.flykhalil.twitter.core.model.ITweet;
import com.github.flykhalil.twitter.core.storage.RepositoryHolder;

import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Objects;
import java.util.UUID;

/**
 * Created by IntelliJ IDEA.
 * User: rsv
 * Date: 09.11.2020
 * Time: 22:24
 */
public class Tweet implements ITweet {

    private static final DateTimeFormatter DATE_TIME_FORMATTER = DateTimeFormatter.ofPattern("yyyy.MM.dd HH:mm:ss");

    private final String tweetText;

    private final UUID id;

    private final long ownerId;

    private final ZonedDateTime tweetTime = ZonedDateTime.now();

    public Tweet(final long ownerId, final String tweetText) {
        this.ownerId = ownerId;
        this.tweetText = tweetText;
        this.id = UUID.randomUUID();
    }

    @Override
    public int hashCode() {
        return Objects.hash(tweetText, id, ownerId);
    }

    @Override
    public boolean equals(final Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        Tweet tweet = (Tweet) o;
        return ownerId == tweet.ownerId && Objects.equals(tweetText, tweet.tweetText) && Objects.equals(id, tweet.id);
    }

    @Override
    public String toString() {
        try {
            return RepositoryHolder.getUserRepository().findById(ownerId).getName() + " " +
                    DATE_TIME_FORMATTER.format(tweetTime) + " : " + tweetText;
        }
        catch (DataAccessException e) {
            return "Unknown user " + DATE_TIME_FORMATTER.format(tweetTime) + ": " + tweetText;
        }
    }

    @Override
    public UUID getId() {
        return id;
    }

    @Override
    public long getOwnerId() {
        return ownerId;
    }

    @Override
    public String getTweetText() {
        return tweetText;
    }

    @Override
    public ZonedDateTime getTweetTime() {
        return tweetTime;
    }
}
