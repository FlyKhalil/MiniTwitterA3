package com.github.flykhalil.twitter.core.exception;

/**
 * Created by IntelliJ IDEA.
 * User: rsv
 * Date: 10.11.2020
 * Time: 0:43
 */
public class DataAccessException extends Exception {

    public DataAccessException(final String message, final Throwable cause) {
        super(message, cause);
    }
}
