package com.github.flykhalil.twitter.core.storage;

import com.github.flykhalil.twitter.core.exception.DataAccessException;
import com.github.flykhalil.twitter.core.model.IGroup;
import com.github.flykhalil.twitter.core.model.impl.Group;

import java.io.IOException;

/**
 * Created by IntelliJ IDEA.
 * User: rsv
 * Date: 09.11.2020
 * Time: 22:10
 */
public class GroupRepository extends AbstractFileRepository<IGroup, Long> {

    public GroupRepository() throws IOException, DataAccessException {
        super();
        putRootIfNotExists();
    }

    private void putRootIfNotExists() throws DataAccessException {
        if (findAll().values().stream().noneMatch(group -> "ROOT".equals(group.getName()))) {
            save(0L, new Group(0, "ROOT"));
        }
    }

    public IGroup findByName(final String name) throws DataAccessException {
        return findAll().values().stream().filter(group -> name.equals(group.getName())).findFirst().orElse(null);
    }
}
