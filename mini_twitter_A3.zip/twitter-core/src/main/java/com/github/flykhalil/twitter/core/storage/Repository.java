package com.github.flykhalil.twitter.core.storage;

import com.github.flykhalil.twitter.core.exception.DataAccessException;

import java.io.Serializable;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.Callable;

/**
 * Created by IntelliJ IDEA.
 * User: rsv
 * Date: 09.11.2020
 * Time: 20:19
 */
public interface Repository <T extends Serializable, ID extends Serializable> {

    UUID addSaveListener(Callable<Void> listener);

    void removeListener(UUID listenerId);

    void save(ID id, T obj) throws DataAccessException;

    T findById(ID id) throws DataAccessException;

    Map<ID, T> findAll() throws DataAccessException;
}
