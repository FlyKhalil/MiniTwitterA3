package com.github.flykhalil.twitter.core.storage;

import com.github.flykhalil.twitter.core.exception.DataAccessException;
import com.github.flykhalil.twitter.core.model.IUser;

import java.io.IOException;
import java.util.Comparator;

/**
 * Created by IntelliJ IDEA.
 * User: rsv
 * Date: 09.11.2020
 * Time: 20:19
 */
public class UserRepository extends AbstractFileRepository<IUser, Long> {

    public UserRepository() throws IOException, DataAccessException {
        super();
    }

    public IUser findFirstOrderByLastUpdatedTimeDesc() throws DataAccessException {
        return RepositoryHolder.getUserRepository().findAll().values().stream()
                               .min(Comparator.comparingLong(IUser::getLastUpdateTime)).orElse(null);
    }
}
