package com.github.flykhalil.twitter.ui;

import javax.swing.*;
import java.awt.*;

/**
 * Created by IntelliJ IDEA.
 * User: rsv
 * Date: 10.11.2020
 * Time: 23:12
 */
public final class DialogUtil {

    private DialogUtil() {
    }

    public static void showInfo(final Component parentComponent, final String text) {
        JOptionPane.showMessageDialog(parentComponent, text);
    }

    public static void showErrorMsg(final Component parentComponent, final Exception exception) {
        exception.printStackTrace();
        JOptionPane.showMessageDialog(parentComponent, exception.getMessage());
    }
}
