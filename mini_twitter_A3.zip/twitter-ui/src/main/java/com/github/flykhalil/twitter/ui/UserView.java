package com.github.flykhalil.twitter.ui;

import com.github.flykhalil.twitter.core.exception.DataAccessException;
import com.github.flykhalil.twitter.core.model.IFeed;
import com.github.flykhalil.twitter.core.model.ITweet;
import com.github.flykhalil.twitter.core.model.IUser;
import com.github.flykhalil.twitter.core.model.impl.Feed;
import com.github.flykhalil.twitter.core.model.impl.Tweet;
import com.github.flykhalil.twitter.core.storage.RepositoryHolder;
import com.intellij.uiDesigner.core.GridConstraints;
import com.intellij.uiDesigner.core.GridLayoutManager;

import javax.swing.*;
import java.awt.*;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.List;
import java.util.*;
import java.util.concurrent.Callable;

/**
 * Created by IntelliJ IDEA.
 * User: rsv
 * Date: 10.11.2020
 * Time: 2:19
 */
public class UserView extends JFrame {

    private final JFrame parent;

    private final IFeed feed;

    private final UUID saveUserListenerId;

    private final UUID saveTweetListenerId;

    private JTextField textFieldFollowingUserId;

    private JButton buttonFollowUser;

    private JList<IUser> listCurrentFollowing;

    private JTextField textFieldTweetMessage;

    private JButton buttonPostTweet;

    private JList<ITweet> listNewsFeed;

    private JPanel panelMain;

    private IUser user;

    public UserView(final IUser user) {
        this.parent = this;
        this.feed = new Feed();
        this.user = user;
        setSize(800, 600);
        setResizable(false);
        setContentPane(panelMain);
        Callable<Void> updateComponentsCallable = () -> {
            try {
                updateComponents();
            }
            catch (Exception e) {
                DialogUtil.showErrorMsg(parent, e);
            }
            return null;
        };
        this.saveTweetListenerId = RepositoryHolder.getTweetRepository().addSaveListener(updateComponentsCallable);
        this.saveUserListenerId = RepositoryHolder.getUserRepository().addSaveListener(updateComponentsCallable);
        try {
            updateComponents();
        }
        catch (Exception e) {
            DialogUtil.showErrorMsg(parent, e);
        }
        buttonFollowUser.addActionListener(e -> {
            try {
                String followingUserIdString = textFieldFollowingUserId.getText();
                followUser(user, Long.parseLong(followingUserIdString));
            }
            catch (Exception exception) {
                DialogUtil.showErrorMsg(parent, exception);
            }
        });
        buttonPostTweet.addActionListener(e -> {
            String tweetText = textFieldTweetMessage.getText();
            try {
                postTweet(user, tweetText);
            }
            catch (Exception exception) {
                DialogUtil.showErrorMsg(parent, exception);
            }
        });
        this.addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(final WindowEvent e) {
                super.windowClosing(e);
                RepositoryHolder.getTweetRepository().removeListener(saveTweetListenerId);
                RepositoryHolder.getUserRepository().removeListener(saveUserListenerId);
            }
        });
    }

    private void updateComponents() throws DataAccessException {
        updateUser();
        updateFeed(user);
        updateFollowingList(user);
        setTitle(user.toString() + ". Created at " +
                         LocalDateTime.ofInstant(Instant.ofEpochMilli(user.getCreationTime()), ZoneId.systemDefault()) +
                         ". Last updated at " +
                         LocalDateTime.ofInstant(Instant.ofEpochMilli(user.getLastUpdateTime()), ZoneId.systemDefault()));
    }

    private void followUser(final IUser user, final long followingUserId) throws DataAccessException {
        IUser following = RepositoryHolder.getUserRepository().findById(followingUserId);
        if (following == null) {
            throw new IllegalArgumentException("No such user with id " + followingUserId);
        }
        user.addFollowingUserId(following.getId());
        following.addFollowerUserId(user.getId());
        RepositoryHolder.getUserRepository().save(user.getId(), user);
        RepositoryHolder.getUserRepository().save(following.getId(), following);
    }

    private void postTweet(final IUser user, final String tweetText) throws DataAccessException {
        if (tweetText == null || tweetText.isEmpty()) {
            throw new IllegalArgumentException("Can't post an empty tweet");
        }
        ITweet tweet = new Tweet(user.getId(), tweetText);
        RepositoryHolder.getTweetRepository().save(UUID.randomUUID(), tweet);
    }

    private void updateUser() throws DataAccessException {
        user = RepositoryHolder.getUserRepository().findById(user.getId());
    }

    private void updateFeed(final IUser user) throws DataAccessException {
        Set<ITweet> tweets = feed.getFeedForUser(user.getId());
        List<ITweet> sortedTweets = new ArrayList<>(tweets);
        sortedTweets.sort(Comparator.comparing(ITweet::getTweetTime));
        DefaultListModel<ITweet> listModel = new DefaultListModel<>();
        for (ITweet tweet : sortedTweets) {
            listModel.addElement(tweet);
        }
        listNewsFeed.setModel(listModel);
    }

    private void updateFollowingList(final IUser user) throws DataAccessException {
        DefaultListModel<IUser> listModel = new DefaultListModel<>();
        Set<Long> followingUserIds = RepositoryHolder.getUserRepository().findById(user.getId()).getFollowingUserIds();
        for (Long followingUserId : followingUserIds) {
            listModel.addElement(RepositoryHolder.getUserRepository().findById(followingUserId));
        }
        listCurrentFollowing.setModel(listModel);
    }

    {
// GUI initializer generated by IntelliJ IDEA GUI Designer
// >>> IMPORTANT!! <<<
// DO NOT EDIT OR ADD ANY CODE HERE!
        $$$setupUI$$$();
    }

    /**
     * Method generated by IntelliJ IDEA GUI Designer
     * >>> IMPORTANT!! <<<
     * DO NOT edit this method OR call it in your code!
     */
    private void $$$setupUI$$$() {
        panelMain = new JPanel();
        panelMain.setLayout(new GridLayoutManager(4, 2, new Insets(10, 10, 10, 10), -1, -1));
        textFieldFollowingUserId = new JTextField();
        panelMain.add(textFieldFollowingUserId,
                      new GridConstraints(0, 0, 1, 1, GridConstraints.ANCHOR_WEST, GridConstraints.FILL_HORIZONTAL,
                                          GridConstraints.SIZEPOLICY_WANT_GROW, GridConstraints.SIZEPOLICY_FIXED, null,
                                          new Dimension(150, -1), null, 0, false));
        buttonFollowUser = new JButton();
        buttonFollowUser.setText("Follow User");
        panelMain.add(buttonFollowUser,
                      new GridConstraints(0, 1, 1, 1, GridConstraints.ANCHOR_CENTER, GridConstraints.FILL_HORIZONTAL,
                                          GridConstraints.SIZEPOLICY_CAN_SHRINK | GridConstraints.SIZEPOLICY_CAN_GROW,
                                          GridConstraints.SIZEPOLICY_FIXED, null, null, null, 0, false));
        textFieldTweetMessage = new JTextField();
        panelMain.add(textFieldTweetMessage,
                      new GridConstraints(2, 0, 1, 1, GridConstraints.ANCHOR_WEST, GridConstraints.FILL_HORIZONTAL,
                                          GridConstraints.SIZEPOLICY_WANT_GROW, GridConstraints.SIZEPOLICY_FIXED, null,
                                          new Dimension(150, -1), null, 0, false));
        buttonPostTweet = new JButton();
        buttonPostTweet.setText("Post Tweet");
        panelMain.add(buttonPostTweet,
                      new GridConstraints(2, 1, 1, 1, GridConstraints.ANCHOR_CENTER, GridConstraints.FILL_HORIZONTAL,
                                          GridConstraints.SIZEPOLICY_CAN_SHRINK | GridConstraints.SIZEPOLICY_CAN_GROW,
                                          GridConstraints.SIZEPOLICY_FIXED, null, null, null, 0, false));
        final JScrollPane scrollPane1 = new JScrollPane();
        panelMain.add(scrollPane1, new GridConstraints(1, 0, 1, 2, GridConstraints.ANCHOR_CENTER, GridConstraints.FILL_BOTH,
                                                       GridConstraints.SIZEPOLICY_CAN_SHRINK |
                                                               GridConstraints.SIZEPOLICY_WANT_GROW,
                                                       GridConstraints.SIZEPOLICY_CAN_SHRINK |
                                                               GridConstraints.SIZEPOLICY_WANT_GROW, null, null, null, 0, false));
        listCurrentFollowing = new JList();
        scrollPane1.setViewportView(listCurrentFollowing);
        final JScrollPane scrollPane2 = new JScrollPane();
        panelMain.add(scrollPane2, new GridConstraints(3, 0, 1, 2, GridConstraints.ANCHOR_CENTER, GridConstraints.FILL_BOTH,
                                                       GridConstraints.SIZEPOLICY_CAN_SHRINK |
                                                               GridConstraints.SIZEPOLICY_WANT_GROW,
                                                       GridConstraints.SIZEPOLICY_CAN_SHRINK |
                                                               GridConstraints.SIZEPOLICY_WANT_GROW, null, null, null, 0, false));
        listNewsFeed = new JList();
        listNewsFeed.setLayoutOrientation(0);
        scrollPane2.setViewportView(listNewsFeed);
    }

    /**
     *
     */
    public JComponent $$$getRootComponent$$$() { return panelMain; }
}
