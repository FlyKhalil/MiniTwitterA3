package com.github.flykhalil.twitter.ui;

import com.github.flykhalil.twitter.core.exception.DataAccessException;
import com.github.flykhalil.twitter.core.model.IAdminPanel;
import com.github.flykhalil.twitter.core.model.IGroup;
import com.github.flykhalil.twitter.core.model.IUser;
import com.github.flykhalil.twitter.core.model.impl.AdminPanel;
import com.github.flykhalil.twitter.core.model.impl.Group;
import com.github.flykhalil.twitter.core.model.impl.User;
import com.github.flykhalil.twitter.core.storage.RepositoryHolder;
import com.intellij.uiDesigner.core.GridConstraints;
import com.intellij.uiDesigner.core.GridLayoutManager;

import javax.swing.*;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.DefaultTreeModel;
import javax.swing.tree.TreeModel;
import java.awt.*;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.UUID;
import java.util.concurrent.Callable;

/**
 * Created by IntelliJ IDEA.
 * User: rsv
 * Date: 10.11.2020
 * Time: 1:36
 */
public class AdminControlPanel extends JFrame {

    private final JFrame root;

    private JPanel panelMain;

    private JTree treeGroups;

    private JTextField textFieldUserId;

    private JTextField textFieldGroupId;

    private JButton buttonAddUser;

    private JButton buttonAddGroup;

    private JButton buttonShowUserTotal;

    private JButton buttonShowGroupTotal;

    private JButton buttonShowTweetsTotal;

    private JButton buttonShowPositivePercentage;

    private JButton buttonOpenUserView;

    private JButton validIdsButton;

    private JButton getLastUpdatedUserButton;

    private IAdminPanel adminPanel;

    private UUID saveGroupListenerId;

    public AdminControlPanel(final String title) {
        super(title);
        root = this;
        try {
            adminPanel = new AdminPanel();
            setContentPane(panelMain);
            setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            setSize(800, 600);
            setResizable(false);
            updateComponents();
            Callable<Void> updateCallable = () -> {
                updateComponents();
                return null;
            };
            saveGroupListenerId = RepositoryHolder.getGroupRepository().addSaveListener(updateCallable);
        }
        catch (Exception e) {
            DialogUtil.showErrorMsg(root, e);
        }
        buttonAddUser.addActionListener(e -> {
            try {
                IGroup selectedGroup = getSelectedGroup();
                TextFieldView textFieldView = new TextFieldView(root, "Add User", "Create User");
                textFieldView.setVisible(true);
                String username = textFieldView.getText();
                String userIdString = textFieldUserId.getText();
                if (username != null && !username.isEmpty() && userIdString != null && !userIdString.isEmpty()) {
                    saveUser(selectedGroup, userIdString, username);
                    DialogUtil.showInfo(root, String.format("User \"%s\" with id %s was created.", username, userIdString));
                }
            }
            catch (Exception exception) {
                DialogUtil.showErrorMsg(root, exception);
            }
        });
        buttonAddGroup.addActionListener(e -> {
            try {
                IGroup selectedGroup = getSelectedGroup();
                TextFieldView textFieldView = new TextFieldView(root, "Add Group", "Create Group");
                textFieldView.setVisible(true);
                String groupName = textFieldView.getText();
                String groupIdString = textFieldGroupId.getText();
                if (groupName != null && !groupName.isEmpty() && groupIdString != null && !groupIdString.isEmpty()) {
                    saveGroup(selectedGroup, groupIdString, groupName);
                    DialogUtil.showInfo(root, String.format("Group \"%s\" with id %s was created.", groupName, groupIdString));
                }
            }
            catch (Exception exception) {
                DialogUtil.showErrorMsg(root, exception);
            }
        });
        buttonShowUserTotal.addActionListener(e -> {
            try {
                DialogUtil.showInfo(root, String.format("Total number of users is %s", adminPanel.getTotalNumberOfUsers()));
            }
            catch (Exception exception) {
                DialogUtil.showErrorMsg(root, exception);
            }
        });
        buttonShowGroupTotal.addActionListener(e -> {
            try {
                DialogUtil.showInfo(root, String.format("Total number of groups is %s", adminPanel.getTotalNumberOfGroups()));
            }
            catch (Exception exception) {
                DialogUtil.showErrorMsg(root, exception);
            }
        });
        buttonShowTweetsTotal.addActionListener(e -> {
            try {
                DialogUtil.showInfo(root, String.format("Total number of tweets is %s", adminPanel.getTotalNumberOfTweets()));
            }
            catch (Exception exception) {
                DialogUtil.showErrorMsg(root, exception);
            }
        });
        buttonShowPositivePercentage.addActionListener(e -> {
            try {
                DialogUtil.showInfo(root, String.format("Positive percentage of tweets is %.2f%%",
                                                        adminPanel.getPositivePercentageOfTweets() * 100));
            }
            catch (Exception exception) {
                DialogUtil.showErrorMsg(root, exception);
            }
        });
        this.addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(final WindowEvent e) {
                super.windowClosing(e);
                RepositoryHolder.getGroupRepository().removeListener(saveGroupListenerId);
            }
        });
        buttonOpenUserView.addActionListener(e -> {
            try {
                IUser selectedUser = getSelectedUser();
                UserView userView = new UserView(selectedUser);
                userView.setVisible(true);
            }
            catch (Exception exception) {
                DialogUtil.showErrorMsg(root, exception);
            }
        });
        validIdsButton.addActionListener(e -> {
            try {
                String userIdString = textFieldUserId.getText();
                String userIdValidationResult = getUserIdValidationResult(userIdString);
                String groupIdString = textFieldGroupId.getText();
                String groupIdValidationResult = getGroupIdValidationResult(groupIdString);
                DialogUtil.showInfo(root, String.format("User ID validation result - %s\nGroup ID validation result - %s",
                                                        userIdValidationResult, groupIdValidationResult));
            }
            catch (Exception exception) {
                DialogUtil.showErrorMsg(root, exception);
            }
        });
        getLastUpdatedUserButton.addActionListener(e -> {
            try {
                IUser lastUpdatedUser = RepositoryHolder.getUserRepository().findFirstOrderByLastUpdatedTimeDesc();
                String lastUpdateUserString = lastUpdatedUser == null ? "There are no last updated user" :
                                              lastUpdatedUser.toString() + ". Last updated at " + LocalDateTime
                                                      .ofInstant(Instant.ofEpochMilli(lastUpdatedUser.getLastUpdateTime()),
                                                                 ZoneId.systemDefault());
                DialogUtil.showInfo(root, "Last updated user info: " + lastUpdateUserString);
            }
            catch (Exception exception) {
                DialogUtil.showErrorMsg(root, exception);
            }
        });
    }

    public static void main(String[] args) {
        AdminControlPanel frame = new AdminControlPanel("Admin Control Panel");
        frame.setVisible(true);
    }

    private String getUserIdValidationResult(final String userIdString) throws DataAccessException {
        if (userIdString == null || userIdString.isEmpty()) {
            return "Error: User ID is empty";
        }
        if (userIdString.contains(" ")) {
            return "Error: User ID can't contain spaces";
        }
        long userId = Long.parseLong(userIdString);
        if (RepositoryHolder.getUserRepository().findById(userId) != null) {
            return String.format("Error: User ID %s is taken", userIdString);
        }
        return "User ID is correct!";
    }

    private String getGroupIdValidationResult(final String groupIdString) throws DataAccessException {
        if (groupIdString == null || groupIdString.isEmpty()) {
            return "Error: Group ID is empty";
        }
        if (groupIdString.contains(" ")) {
            return "Error: Group ID can't contain spaces";
        }
        long groupId = Long.parseLong(groupIdString);
        if (RepositoryHolder.getGroupRepository().findById(groupId) != null) {
            return String.format("Error: Group ID %s is taken", groupIdString);
        }
        return "Group ID is correct!";
    }

    private void updateComponents() {
        try {
            treeGroups.setModel(null);
            IGroup rootGroup = RepositoryHolder.getGroupRepository().findByName("ROOT");
            if (rootGroup == null) {
                throw new IllegalStateException("ROOT group doesn't exist");
            }
            DefaultMutableTreeNode root = createGroupTree(rootGroup);
            TreeModel treeModel = new DefaultTreeModel(root);
            treeGroups.setModel(treeModel);
        }
        catch (Exception e) {
            DialogUtil.showErrorMsg(root, e);
        }
    }

    private void saveUser(final IGroup selectedGroup, final String userIdString, final String username)
            throws DataAccessException {
        long userId = Long.parseLong(userIdString);
        selectedGroup.addUserId(userId);
        IUser user = new User(userId, username);
        RepositoryHolder.getUserRepository().save(userId, user);
        RepositoryHolder.getGroupRepository().save(selectedGroup.getId(), selectedGroup);
    }

    private void saveGroup(final IGroup selectedGroup, final String groupIdString, final String groupName)
            throws DataAccessException {
        long groupId = Long.parseLong(groupIdString);
        selectedGroup.addSubGroupId(groupId);
        IGroup group = new Group(groupId, groupName);
        RepositoryHolder.getGroupRepository().save(groupId, group);
        RepositoryHolder.getGroupRepository().save(selectedGroup.getId(), selectedGroup);
    }

    private DefaultMutableTreeNode createGroupTree(final IGroup rootGroup) throws DataAccessException {
        DefaultMutableTreeNode rootNode = new DefaultMutableTreeNode(rootGroup);
        for (Long usersId : rootGroup.getUsersIds()) {
            IUser user = RepositoryHolder.getUserRepository().findById(usersId);
            rootNode.add(new DefaultMutableTreeNode(user));
        }
        for (Long subGroupsId : rootGroup.getSubGroupsIds()) {
            IGroup group = RepositoryHolder.getGroupRepository().findById(subGroupsId);
            rootNode.add(createGroupTree(group));
        }
        return rootNode;
    }

    {
// GUI initializer generated by IntelliJ IDEA GUI Designer
// >>> IMPORTANT!! <<<
// DO NOT EDIT OR ADD ANY CODE HERE!
        $$$setupUI$$$();
    }

    /**
     * Method generated by IntelliJ IDEA GUI Designer
     * >>> IMPORTANT!! <<<
     * DO NOT edit this method OR call it in your code!
     */
    private void $$$setupUI$$$() {
        panelMain = new JPanel();
        panelMain.setLayout(new GridLayoutManager(7, 3, new Insets(10, 10, 10, 10), -1, -1));
        treeGroups = new JTree();
        panelMain.add(treeGroups, new GridConstraints(0, 0, 7, 1, GridConstraints.ANCHOR_CENTER, GridConstraints.FILL_BOTH,
                                                      GridConstraints.SIZEPOLICY_FIXED, GridConstraints.SIZEPOLICY_WANT_GROW,
                                                      null, new Dimension(300, 50), null, 0, false));
        textFieldUserId = new JTextField();
        panelMain.add(textFieldUserId,
                      new GridConstraints(0, 1, 1, 1, GridConstraints.ANCHOR_WEST, GridConstraints.FILL_HORIZONTAL,
                                          GridConstraints.SIZEPOLICY_WANT_GROW, GridConstraints.SIZEPOLICY_FIXED, null,
                                          new Dimension(220, 30), null, 0, false));
        textFieldGroupId = new JTextField();
        panelMain.add(textFieldGroupId,
                      new GridConstraints(1, 1, 1, 1, GridConstraints.ANCHOR_WEST, GridConstraints.FILL_HORIZONTAL,
                                          GridConstraints.SIZEPOLICY_WANT_GROW, GridConstraints.SIZEPOLICY_FIXED, null,
                                          new Dimension(220, 30), null, 0, false));
        buttonAddUser = new JButton();
        buttonAddUser.setText("Add User");
        panelMain.add(buttonAddUser,
                      new GridConstraints(0, 2, 1, 1, GridConstraints.ANCHOR_CENTER, GridConstraints.FILL_HORIZONTAL, 1,
                                          GridConstraints.SIZEPOLICY_FIXED, null, null, null, 0, false));
        buttonAddGroup = new JButton();
        buttonAddGroup.setText("Add Group");
        panelMain.add(buttonAddGroup,
                      new GridConstraints(1, 2, 1, 1, GridConstraints.ANCHOR_CENTER, GridConstraints.FILL_HORIZONTAL, 1,
                                          GridConstraints.SIZEPOLICY_FIXED, null, null, null, 0, false));
        buttonShowUserTotal = new JButton();
        buttonShowUserTotal.setText("Show User Total");
        panelMain.add(buttonShowUserTotal,
                      new GridConstraints(5, 1, 1, 1, GridConstraints.ANCHOR_CENTER, GridConstraints.FILL_HORIZONTAL, 1,
                                          GridConstraints.SIZEPOLICY_FIXED, null, new Dimension(220, 30), null, 0, false));
        buttonShowGroupTotal = new JButton();
        buttonShowGroupTotal.setText("Show Group Total");
        panelMain.add(buttonShowGroupTotal,
                      new GridConstraints(5, 2, 1, 1, GridConstraints.ANCHOR_CENTER, GridConstraints.FILL_HORIZONTAL, 1,
                                          GridConstraints.SIZEPOLICY_FIXED, null, null, null, 0, false));
        buttonShowTweetsTotal = new JButton();
        buttonShowTweetsTotal.setText("Show Tweets Total");
        panelMain.add(buttonShowTweetsTotal,
                      new GridConstraints(6, 1, 1, 1, GridConstraints.ANCHOR_CENTER, GridConstraints.FILL_HORIZONTAL, 1,
                                          GridConstraints.SIZEPOLICY_FIXED, null, new Dimension(220, 30), null, 0, false));
        buttonShowPositivePercentage = new JButton();
        buttonShowPositivePercentage.setText("Show Positive Percentage");
        panelMain.add(buttonShowPositivePercentage,
                      new GridConstraints(6, 2, 1, 1, GridConstraints.ANCHOR_CENTER, GridConstraints.FILL_HORIZONTAL, 1,
                                          GridConstraints.SIZEPOLICY_FIXED, null, null, null, 0, false));
        buttonOpenUserView = new JButton();
        buttonOpenUserView.setText("Open User View");
        panelMain.add(buttonOpenUserView,
                      new GridConstraints(4, 1, 1, 2, GridConstraints.ANCHOR_CENTER, GridConstraints.FILL_HORIZONTAL, 1,
                                          GridConstraints.SIZEPOLICY_FIXED, null, null, null, 0, false));
        validIdsButton = new JButton();
        validIdsButton.setText("User/Group ID Verification");
        panelMain.add(validIdsButton,
                      new GridConstraints(2, 1, 1, 2, GridConstraints.ANCHOR_CENTER, GridConstraints.FILL_HORIZONTAL,
                                          GridConstraints.SIZEPOLICY_CAN_SHRINK | GridConstraints.SIZEPOLICY_CAN_GROW,
                                          GridConstraints.SIZEPOLICY_FIXED, null, null, null, 0, false));
        getLastUpdatedUserButton = new JButton();
        getLastUpdatedUserButton.setText("Get Last Updated User");
        panelMain.add(getLastUpdatedUserButton,
                      new GridConstraints(3, 1, 1, 2, GridConstraints.ANCHOR_CENTER, GridConstraints.FILL_HORIZONTAL,
                                          GridConstraints.SIZEPOLICY_CAN_SHRINK | GridConstraints.SIZEPOLICY_CAN_GROW,
                                          GridConstraints.SIZEPOLICY_FIXED, null, null, null, 0, false));
    }

    /**
     *
     */
    public JComponent $$$getRootComponent$$$() { return panelMain; }

    private IUser getSelectedUser() {
        DefaultMutableTreeNode selectedNode = (DefaultMutableTreeNode) treeGroups.getLastSelectedPathComponent();
        if (selectedNode == null) {
            throw new IllegalArgumentException("Please select a user first");
        }
        Object userObj = selectedNode.getUserObject();
        IUser result;
        if (userObj instanceof IUser) {
            result = (IUser) userObj;
        }
        else {
            throw new IllegalArgumentException("Please select a group");
        }
        return result;
    }

    private IGroup getSelectedGroup() {
        DefaultMutableTreeNode selectedNode = (DefaultMutableTreeNode) treeGroups.getLastSelectedPathComponent();
        if (selectedNode == null) {
            throw new IllegalArgumentException("Please select a group first");
        }
        Object userObj = selectedNode.getUserObject();
        IGroup result;
        if (userObj instanceof IGroup) {
            result = (IGroup) userObj;
        }
        else if (userObj instanceof IUser) {
            DefaultMutableTreeNode parentNode = (DefaultMutableTreeNode) selectedNode.getParent();
            userObj = parentNode.getUserObject();
            if (userObj instanceof IGroup) {
                result = (IGroup) userObj;
            }
            else {
                throw new IllegalArgumentException("Unknown node type");
            }
        }
        else {
            throw new IllegalArgumentException("Unknown node type");
        }
        return result;
    }
}
